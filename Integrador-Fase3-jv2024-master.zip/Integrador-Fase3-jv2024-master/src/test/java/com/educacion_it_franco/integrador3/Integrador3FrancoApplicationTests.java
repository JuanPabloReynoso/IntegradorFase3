package com.educacion_it_franco.integrador3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Integrador3FrancoApplicationTests {

	@Test
	void contextLoads() {
	}

}
