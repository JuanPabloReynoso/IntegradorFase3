package tienda.discos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiscosApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiscosApplication.class, args);
	}

}
 