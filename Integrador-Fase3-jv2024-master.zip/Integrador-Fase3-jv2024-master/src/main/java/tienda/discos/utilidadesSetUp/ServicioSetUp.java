package tienda.discos.utilidadesSetUp;

public interface ServicioSetUp {
	void prepararSetup();
}