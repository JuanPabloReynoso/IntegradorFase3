let plantillaInicio = "";
let plantillaDiscos = "";
let plantillaRegistro = "";
let plantillaLogIn = "";
let plantillaCarrito = "";
let plantillaDetallesDisco = "";
let plantillaCheckoutUno = "";
let plantillaCheckoutDos = "";
let plantillaCheckoutTres = "";
let plantillaCheckoutFinal = "";
let plantillaPedidos = "";
let plantillaPerfil = "";

// var que nos indica si el user está identificado
let nombre_login = "";
